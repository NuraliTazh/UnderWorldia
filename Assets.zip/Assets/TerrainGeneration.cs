using UnityEngine;

public class TerrainGeneration : MonoBehaviour
{
    public Sprite tile;
    public int worldSize = 100;
    public float CaveFreq = 0.05f;
    public float TerrainFreq = 0.04f;
    public float heightMultiplier = 25f;
    public int heightAddition = 25;
    public float seed;
    public Texture2D noiseTexture;

    private void Start()
    {
        seed = Random.Range(-10000, 10000);
        GenerateNoiseTexture();
        GenerateTerrain();
    }

    public void GenerateTerrain()
    {
        for (int i = 0; i < worldSize; i++)
        {
            float height = Mathf.PerlinNoise((i + seed) * TerrainFreq, seed * TerrainFreq) * heightMultiplier + heightAddition;
            for (int j = 0; j < height; j++)
            {
                if (noiseTexture.GetPixel(i, j).r > 0.25f)
                {
                    GameObject newTile = new GameObject("Tile");
                    newTile.transform.parent = this.transform;
                    newTile.transform.position = new Vector2(i + 0.5f, j + 0.5f);
                    SpriteRenderer sr = newTile.AddComponent<SpriteRenderer>();
                    sr.sprite = tile;
                }
            }
        }
    }

    public void GenerateNoiseTexture()
    {
        noiseTexture = new Texture2D(worldSize, worldSize);

        for (int i = 0; i < worldSize; i++)
        {
            for (int j = 0; j < worldSize; j++)
            {
                float v = Mathf.PerlinNoise((i + seed) * TerrainFreq, (j + seed) * TerrainFreq);
                noiseTexture.SetPixel(i, j, new Color(v, v, v));
            }
        }

        noiseTexture.Apply();
    }
}
